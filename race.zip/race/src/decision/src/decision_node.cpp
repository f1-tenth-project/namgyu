#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/path.hpp>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>

#include <chrono>
#include <cmath>
#include <algorithm>

class DecisionNode : public rclcpp::Node {
public:
  DecisionNode() : Node("decision_node")
  {
    // ===== 파라미터 (pure_pursuit 원본과 동일하게) =====
    lookahead_ = this->declare_parameter<double>("lookahead", 1.5);      // [m]
    wheelbase_ = this->declare_parameter<double>("wheelbase", 0.34);     // [m]
    v_min_     = this->declare_parameter<double>("speed_min", 1.0);      // [m/s]
    v_max_     = this->declare_parameter<double>("speed_max", 4.0);      // [m/s]
    k_speed_   = this->declare_parameter<double>("k_speed",  2.5);       // curvature → speed

    // 토픽 이름(필요하면 나중에 파라미터화 가능)
    center_path_topic_ = "/center_path";
    odom_topic_        = "/odom0";

    // ===== 구독 설정 =====
    // center_path (nav_msgs/Path)
    center_path_sub_ = this->create_subscription<nav_msgs::msg::Path>(
      center_path_topic_, 1,
      std::bind(&DecisionNode::onCenterPath, this, std::placeholders::_1));

    // odom0 (현재 차량 위치/속도)
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_, 10,
      std::bind(&DecisionNode::onOdom, this, std::placeholders::_1));

    // ===== drive_ref 퍼블리셔 =====
    drive_ref_pub_ = this->create_publisher<ackermann_msgs::msg::AckermannDriveStamped>(
      "/drive_ref", 10);

    // ===== 주기 타이머 (20 ms) =====
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(20),
      std::bind(&DecisionNode::onTimer, this));

    RCLCPP_INFO(this->get_logger(), "DecisionNode (PurePursuit center_path) started!");
  }

private:
  // center_path 콜백
  void onCenterPath(const nav_msgs::msg::Path::SharedPtr msg)
  {
    center_path_ = *msg;
  }

  // odom 콜백
  void onOdom(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    odom_ = *msg;
    has_odom_ = true;
  }

  // pure_pursuit: lookahead 인덱스 찾기
  static int findLookaheadIndex(const nav_msgs::msg::Path &path,
                                double x, double y, double Ld)
  {
    if (path.poses.empty()) return -1;

    int closest = 0;
    double best = 1e18;

    for (size_t i = 0; i < path.poses.size(); ++i) {
      const auto &pt = path.poses[i].pose.position;
      double d2 = (pt.x - x) * (pt.x - x) + (pt.y - y) * (pt.y - y);
      if (d2 < best) {
        best = d2;
        closest = static_cast<int>(i);
      }
    }

    double accum = 0.0;
    for (size_t i = closest; i + 1 < path.poses.size(); ++i) {
      const auto &a = path.poses[i].pose.position;
      const auto &b = path.poses[i + 1].pose.position;
      accum += std::hypot(b.x - a.x, b.y - a.y);
      if (accum >= Ld) {
        return static_cast<int>(i + 1);
      }
    }

    return static_cast<int>(path.poses.size() - 1);
  }

  void onTimer()
  {
    if (!has_odom_ || center_path_.poses.empty()) {
      return;
    }

    // ===== 현재 자세(x,y,yaw) =====
    const auto &p = odom_.pose.pose.position;
    const auto &q = odom_.pose.pose.orientation;
    double roll, pitch, yaw;
    tf2::Quaternion tq(q.x, q.y, q.z, q.w);
    tf2::Matrix3x3(tq).getRPY(roll, pitch, yaw);
    const double x = p.x;
    const double y = p.y;

    // ===== lookahead 타깃 포인트 =====
    const double Ld = lookahead_;
    int target_idx = findLookaheadIndex(center_path_, x, y, Ld);
    if (target_idx < 0) return;

    const auto &tp = center_path_.poses[target_idx].pose.position;

    // ===== 차량 좌표계로 변환 (x 앞, y 좌측) =====
    const double dx = tp.x - x;
    const double dy = tp.y - y;
    const double xL =  std::cos(yaw) * dx + std::sin(yaw) * dy;
    const double yL = -std::sin(yaw) * dx + std::cos(yaw) * dy;
    if (xL <= 0.01) return;

    const double Ld_eff = std::hypot(xL, yL);
    const double curvature = 2.0 * yL / (Ld_eff * Ld_eff);      // kappa
    const double steer_ref = std::atan(wheelbase_ * curvature); // 조향각

    // ===== 곡률 기반 속도(v_ref) =====
    double v_ref = std::max(v_min_, v_max_ - k_speed_ * std::abs(curvature));
    // v_ref = std::clamp(v_ref, v_min_, v_max_);
    if (v_ref < v_min_) v_ref = v_min_;
    if (v_ref > v_max_) v_ref = v_max_;

    // ===== drive_ref publish =====
    ackermann_msgs::msg::AckermannDriveStamped msg;
    msg.header.stamp = this->now();
    msg.header.frame_id = "base_link";
    msg.drive.steering_angle = steer_ref;
    msg.drive.speed          = v_ref;      // 목표 속도
    msg.drive.acceleration   = 0.0;        // 실제 가속도는 control_node에서 계산

    drive_ref_pub_->publish(msg);
  }

  // 상태 변수
  nav_msgs::msg::Path center_path_;
  nav_msgs::msg::Odometry odom_;
  bool has_odom_ = false;

  // 파라미터
  double lookahead_, wheelbase_;
  double v_min_, v_max_, k_speed_;
  std::string center_path_topic_, odom_topic_;

  // ROS 핸들
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr center_path_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr drive_ref_pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<DecisionNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
