from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    perception_node = Node(
        package='perception',
        executable='perception_node',   # ros2 run perception perception_node
        name='perception_node',
        output='screen'
    )

    decision_node = Node(
        package='decision',
        executable='decision_node',     # ros2 run decision decision_node
        name='decision_node',
        output='screen'
    )

    control_node = Node(
        package='control',
        executable='control_node',      # ros2 run control control_node
        name='control_node',
        output='screen'
    )

    return LaunchDescription([
        perception_node,
        decision_node,
        control_node,
    ])
