// pure_pursuit.cpp
#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/path.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <visualization_msgs/msg/marker.hpp>

#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>

class PurePursuitNode : public rclcpp::Node {
public:
  PurePursuitNode() : Node("pure_pursuit_node") {
    // ----- 기본 파라미터 -----
    lookahead_ = declare_parameter<double>("lookahead", 1.5);     // [m] 기본 Ld
    wheelbase_ = declare_parameter<double>("wheelbase", 0.34);    // [m]
    v_min_     = declare_parameter<double>("speed_min", 1.0);     // [m/s]
    v_max_     = declare_parameter<double>("speed_max", 20.0);     // [m/s]
    k_accel_   = declare_parameter<double>("k_accel",  2.0);      // P gain for (v_ref - v)
    a_min_     = declare_parameter<double>("accel_min",-5.0);     // [m/s^2]
    a_max_     = declare_parameter<double>("accel_max",  5.0);    // [m/s^2]

    // ----- 동적 룩어헤드 파라미터 -----
    // Ld = lookahead_ + kv_ld_ * v  (ld_min_ ~ ld_max_ 사이로 clamp)
    kv_ld_   = declare_parameter<double>("kv_ld",   0.3);  // 속도 비례 계수
    ld_min_  = declare_parameter<double>("ld_min",  0.8);  // 최소 Ld
    ld_max_  = declare_parameter<double>("ld_max",  4.0);  // 최대 Ld

    // ----- 동적 곡률 프리뷰 파라미터 -----
    // L_curv = clamp(curv_preview_min_, curv_preview_min_ + curv_preview_t_ * v, curv_preview_max_)
    curv_preview_t_    = declare_parameter<double>("curv_preview_time", 1.0);  // [s] 속도에 곱해줄 시간 헤드웨이
    curv_preview_min_  = declare_parameter<double>("curv_preview_min", 3.0);   // [m] 최소 프리뷰 길이
    curv_preview_max_  = declare_parameter<double>("curv_preview_max", 12.0);  // [m] 최대 프리뷰 길이
    curv_preview_step_ = declare_parameter<double>("curv_preview_step", 0.3);  // [m] 마커 찍는 간격

    // 곡률 기반 속도 제한용 파라미터
    ay_max_          = declare_parameter<double>("ay_max",          6.0); // [m/s^2] 허용 횡가속도
    curv_gain_speed_ = declare_parameter<double>("curv_gain_speed", 1.0); // 곡률 민감도

    center_path_topic_ = declare_parameter<std::string>("center_path_topic", "center_path");
    left_path_topic_   = declare_parameter<std::string>("left_boundary",   "left_boundary");
    right_path_topic_  = declare_parameter<std::string>("right_boundary",  "right_boundary");
    odom_topic_        = declare_parameter<std::string>("odom_topic",      "odom0");
    drive_topic_       = declare_parameter<std::string>("drive_topic",     "ackermann_cmd0");

    // raceline CSV 경로
    center_path_csv_ = declare_parameter<std::string>(
        "center_path_csv",
        "/home/namgyu/race/src/racecar_simulator/maps/lane_process/icra2025/icra2025_raceline.csv"
    );

    // ----- Publisher / Subscriber -----
    drive_pub_ = create_publisher<ackermann_msgs::msg::AckermannDriveStamped>(drive_topic_, 10);

    // raceline Path (RViz)
    raceline_pub_ = create_publisher<nav_msgs::msg::Path>("raceline_path", 10);

    // lookahead Marker (점)
    lookahead_pub_ = create_publisher<visualization_msgs::msg::Marker>("lookahead_marker", 10);

    // 곡률 프리뷰 점들 (여러 개 점)
    curvature_pub_ = create_publisher<visualization_msgs::msg::Marker>("curvature_points", 10);

    // simulator 에서 나오는 center/left/right path (참고용)
    sub_center_ = create_subscription<nav_msgs::msg::Path>(
        center_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ center_path_from_topic_ = *msg; });

    sub_left_ = create_subscription<nav_msgs::msg::Path>(
        left_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ left_path_ = *msg; });

    sub_right_ = create_subscription<nav_msgs::msg::Path>(
        right_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ right_path_ = *msg; });

    sub_odom_ = create_subscription<nav_msgs::msg::Odometry>(
        odom_topic_, rclcpp::QoS(rclcpp::KeepLast(1)).reliable(),
        [this](nav_msgs::msg::Odometry::SharedPtr msg){
          odom_ = *msg; has_odom_ = true;
        });

    // ----- CSV 에서 raceline 로드 (center_path_) -----
    loadCenterPathFromCsv(center_path_csv_);

    // 주행 타이머
    timer_ = create_wall_timer(std::chrono::milliseconds(10),
                               std::bind(&PurePursuitNode::onTimer, this));
  }

private:
  // CSV에서 raceline(center_path_) 읽기
  void loadCenterPathFromCsv(const std::string &csv_path) {
    center_path_.poses.clear();
    center_path_.header.frame_id = "map";

    std::ifstream ifs(csv_path);
    if (!ifs.is_open()) {
      RCLCPP_ERROR(this->get_logger(),
                   "Failed to open center_path csv: %s", csv_path.c_str());
      return;
    }

    std::string line;
    // 첫 줄(헤더) 스킵: x_m,y_m
    if (!std::getline(ifs, line)) {
      RCLCPP_ERROR(this->get_logger(),
                   "center_path csv is empty: %s", csv_path.c_str());
      return;
    }

    int count = 0;
    while (std::getline(ifs, line)) {
      if (line.empty()) continue;
      std::stringstream ss(line);
      std::string sx, sy;
      if (!std::getline(ss, sx, ',')) continue;
      if (!std::getline(ss, sy, ',')) continue;

      try {
        double x = std::stod(sx);
        double y = std::stod(sy);

        geometry_msgs::msg::PoseStamped ps;
        ps.header.frame_id = "map";
        ps.pose.position.x = x;
        ps.pose.position.y = y;
        ps.pose.position.z = 0.0;

        center_path_.poses.push_back(ps);
        ++count;
      } catch (const std::exception &e) {
        RCLCPP_WARN(this->get_logger(),
                    "Failed to parse line in center_path csv: '%s'", line.c_str());
      }
    }

    RCLCPP_INFO(this->get_logger(),
                "Loaded center_path (raceline) from csv: %s (points=%d)",
                csv_path.c_str(), count);
  }

  void onTimer() {
    if (!has_odom_ || center_path_.poses.empty()) return;

    // ----- raceline_path를 주기적으로 publish (RViz에서 항상 보이게) -----
    center_path_.header.frame_id = "map";
    center_path_.header.stamp = now();
    raceline_pub_->publish(center_path_);

    // ----- 현재 자세 -----
    const auto &p = odom_.pose.pose.position;
    const auto &q = odom_.pose.pose.orientation;
    double roll, pitch, yaw;
    tf2::Quaternion tq(q.x, q.y, q.z, q.w);
    tf2::Matrix3x3(tq).getRPY(roll, pitch, yaw);
    const double x = p.x, y = p.y;

    // 현재 속도
    const double v = odom_.twist.twist.linear.x;

    // ----- 동적 룩어헤드 계산 -----
    double Ld = lookahead_ + kv_ld_ * std::max(0.0, v);
    if (Ld < ld_min_) Ld = ld_min_;
    if (Ld > ld_max_) Ld = ld_max_;

    // ----- 조향용 lookahead target -----
    int target_idx = findLookaheadIndex(center_path_, x, y, Ld);
    if (target_idx < 0) return;
    const auto &tp = center_path_.poses[target_idx].pose.position;

    // 차량 좌표계로 변환 (x 앞, y 왼쪽)
    const double dx = tp.x - x;
    const double dy = tp.y - y;
    const double xL =  std::cos(yaw) * dx + std::sin(yaw) * dy;
    const double yL = -std::sin(yaw) * dx + std::cos(yaw) * dy;
    if (xL <= 0.01) return;

    const double curvature_pp = 2.0 * yL / (Ld * Ld);   // pure-pursuit 조향용 곡률
    const double steer = std::atan(wheelbase_ * curvature_pp);

    // ----- lookahead Marker (점) publish -----
    publishLookaheadMarker(tp);

    // ----- 동적 곡률 프리뷰 거리 계산 -----
    double L_curv = curv_preview_min_ + curv_preview_t_ * std::max(0.0, v);
    if (L_curv < curv_preview_min_) L_curv = curv_preview_min_;
    if (L_curv > curv_preview_max_) L_curv = curv_preview_max_;

    // ----- 프리뷰 구간에서 최대 곡률 계산 & 마커 찍기 -----
    std::vector<geometry_msgs::msg::Point> preview_points;
    double kappa_ahead = computeMaxCurvatureAhead(center_path_, x, y,
                                                  L_curv, curv_preview_step_,
                                                  preview_points);
    publishCurvaturePointsMarker(preview_points);

    // ----- 곡률 기반 속도 상한 계산 (ay_max 기반) -----
    double kappa_eff = std::max(1e-6, curv_gain_speed_ * std::abs(kappa_ahead));
    double v_curv = std::sqrt(ay_max_ / kappa_eff);  // [m/s]
    double v_ref  = std::clamp(v_curv, v_min_, v_max_);

    // ----- 가속도 명령 -----
    double a_cmd = k_accel_ * (v_ref - v);
    if (a_cmd > a_max_) a_cmd = a_max_;
    if (a_cmd < a_min_) a_cmd = a_min_;

    ackermann_msgs::msg::AckermannDriveStamped cmd;
    cmd.header.stamp = now();
    cmd.header.frame_id = "base_link";
    cmd.drive.steering_angle = steer;
    cmd.drive.acceleration   = a_cmd;

    drive_pub_->publish(cmd);
  }

  // lookahead 위치를 점(SPHERE) marker로 publish
  void publishLookaheadMarker(const geometry_msgs::msg::Point &pt) {
    visualization_msgs::msg::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = now();
    mk.ns = "lookahead_point";
    mk.id = 0;
    mk.type = visualization_msgs::msg::Marker::SPHERE;
    mk.action = visualization_msgs::msg::Marker::ADD;

    mk.pose.position = pt;
    mk.pose.position.z = 0.1;
    mk.pose.orientation.x = 0.0;
    mk.pose.orientation.y = 0.0;
    mk.pose.orientation.z = 0.0;
    mk.pose.orientation.w = 1.0;

    mk.scale.x = 0.3;
    mk.scale.y = 0.3;
    mk.scale.z = 0.3;

    mk.color.r = 0.0f;
    mk.color.g = 1.0f;
    mk.color.b = 0.0f;
    mk.color.a = 1.0f;

    mk.lifetime = rclcpp::Duration::from_seconds(0.2);

    lookahead_pub_->publish(mk);
  }

  // 곡률 프리뷰 점들(SPHERE_LIST) marker publish
  void publishCurvaturePointsMarker(const std::vector<geometry_msgs::msg::Point> &pts) {
    visualization_msgs::msg::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = now();
    mk.ns = "curvature_points";
    mk.id = 0;
    mk.type = visualization_msgs::msg::Marker::SPHERE_LIST;
    mk.action = visualization_msgs::msg::Marker::ADD;

    mk.scale.x = 0.25;
    mk.scale.y = 0.25;
    mk.scale.z = 0.25;

    mk.color.r = 1.0f;
    mk.color.g = 0.0f;
    mk.color.b = 0.0f;
    mk.color.a = 1.0f;

    mk.points = pts;
    mk.lifetime = rclcpp::Duration::from_seconds(0.2);

    curvature_pub_->publish(mk);
  }

  // path 위에서 누적 거리 기반으로 Ld 떨어진 index 찾기 (조향용)
  static int findLookaheadIndex(const nav_msgs::msg::Path &path,
                                double x, double y, double Ld) {
    if (path.poses.empty()) return -1;

    // 가장 가까운 점 찾기
    int closest = 0;
    double best = 1e18;
    for (size_t i = 0; i < path.poses.size(); ++i) {
      const auto &pt = path.poses[i].pose.position;
      double d2 = (pt.x - x)*(pt.x - x) + (pt.y - y)*(pt.y - y);
      if (d2 < best) { best = d2; closest = static_cast<int>(i); }
    }

    // 그 이후로 거리 누적
    double accum = 0.0;
    for (size_t step = 0; step + 1 < path.poses.size(); ++step) {
      int i = (closest + step) % path.poses.size();
      int j = (closest + step + 1) % path.poses.size();
      const auto &a = path.poses[i].pose.position;
      const auto &b = path.poses[j].pose.position;
      accum += std::hypot(b.x - a.x, b.y - a.y);
      if (accum >= Ld) return j;
    }
    return closest;
  }

  // 동적 프리뷰 거리 L_curv 만큼 앞을 보면서 최대 곡률 |kappa| 계산
  double computeMaxCurvatureAhead(const nav_msgs::msg::Path &path,
                                  double x, double y,
                                  double L_curv, double step_spacing,
                                  std::vector<geometry_msgs::msg::Point> &preview_pts)
  {
    preview_pts.clear();
    if (path.poses.size() < 3) return 0.0;

    // 가장 가까운 index
    int closest = 0;
    double best = 1e18;
    for (size_t i = 0; i < path.poses.size(); ++i) {
      const auto &pt = path.poses[i].pose.position;
      double d2 = (pt.x - x)*(pt.x - x) + (pt.y - y)*(pt.y - y);
      if (d2 < best) { best = d2; closest = static_cast<int>(i); }
    }

    // L_curv 까지 전진하며 점 수집 + 곡률 계산
    double accum = 0.0;
    double max_kappa = 0.0;

    // 최소 하나는 넣자
    preview_pts.push_back(path.poses[closest].pose.position);
    int curr_idx = closest;

    while (accum < L_curv) {
      int next_idx = (curr_idx + 1) % path.poses.size();
      const auto &a = path.poses[curr_idx].pose.position;
      const auto &b = path.poses[next_idx].pose.position;
      double ds = std::hypot(b.x - a.x, b.y - a.y);
      if (ds < 1e-6) break;

      accum += ds;
      curr_idx = next_idx;
      preview_pts.push_back(path.poses[curr_idx].pose.position);

      // step_spacing 보다 가까이 붙은 점은 너무 많아지지 않도록 옵션을 둘 수 있지만
      // 여기서는 path 자체 간격이 충분히 촘촘하다고 가정

      // 곡률 계산 (마지막 3점 사용)
      int n = static_cast<int>(preview_pts.size());
      if (n >= 3) {
        const auto &p1 = preview_pts[n-3];
        const auto &p2 = preview_pts[n-2];
        const auto &p3 = preview_pts[n-1];

        double kappa = computeCurvatureThreePoints(p1, p2, p3);
        if (std::abs(kappa) > std::abs(max_kappa)) {
          max_kappa = kappa;
        }
      }

      if (accum >= L_curv) break;
    }

    return max_kappa;
  }

  // 세 점으로부터 곡률 계산 (부호 포함)
  static double computeCurvatureThreePoints(const geometry_msgs::msg::Point &p1,
                                            const geometry_msgs::msg::Point &p2,
                                            const geometry_msgs::msg::Point &p3)
  {
    double x1 = p1.x, y1 = p1.y;
    double x2 = p2.x, y2 = p2.y;
    double x3 = p3.x, y3 = p3.y;

    // 세 변의 길이
    double a = std::hypot(x2 - x1, y2 - y1);
    double b = std::hypot(x3 - x2, y3 - y2);
    double c = std::hypot(x3 - x1, y3 - y1);

    double s = 0.5 * (a + b + c);
    double area2 = s * (s - a) * (s - b) * (s - c);
    if (area2 <= 1e-12) return 0.0;

    double area = std::sqrt(area2);                 // 삼각형 면적
    double radius = (a * b * c) / (4.0 * area);     // 외접원 반지름
    double kappa = 1.0 / radius;                   // 곡률 크기

    // 방향(부호)은 cross product 로
    double vx1 = x2 - x1;
    double vy1 = y2 - y1;
    double vx2 = x3 - x2;
    double vy2 = y3 - y2;
    double cross = vx1 * vy2 - vy1 * vx2;
    if (cross < 0.0) kappa = -kappa; // 우회전이면 음수, 좌회전이면 양수

    return kappa;
  }

  // ----- 멤버 변수 -----
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr drive_pub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr raceline_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr lookahead_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr curvature_pub_;

  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr sub_center_, sub_left_, sub_right_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr sub_odom_;
  rclcpp::TimerBase::SharedPtr timer_;

  nav_msgs::msg::Path center_path_;             // CSV에서 읽은 raceline (실제 추종용)
  nav_msgs::msg::Path center_path_from_topic_;  // simulator centerline (참고용)
  nav_msgs::msg::Path left_path_, right_path_;

  nav_msgs::msg::Odometry odom_;
  bool has_odom_{false};

  // 파라미터들
  double lookahead_, wheelbase_;
  double v_min_, v_max_;
  double k_accel_, a_min_, a_max_;

  // 동적 lookahead
  double kv_ld_, ld_min_, ld_max_;

  // 동적 곡률 프리뷰
  double curv_preview_t_, curv_preview_min_, curv_preview_max_;
  double curv_preview_step_;

  // 곡률 기반 속도 제한
  double ay_max_;
  double curv_gain_speed_;

  std::string center_path_topic_, left_path_topic_, right_path_topic_;
  std::string odom_topic_, drive_topic_;
  std::string center_path_csv_;
};

int main(int argc, char **argv){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PurePursuitNode>());
  rclcpp::shutdown();
  return 0;
}
