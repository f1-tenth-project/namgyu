// pure_pursuit.cpp
#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/path.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <visualization_msgs/msg/marker.hpp>

#include <fstream>
#include <sstream>
#include <string>

class PurePursuitNode : public rclcpp::Node {
public:
  PurePursuitNode() : Node("pure_pursuit_node") {
    // ----- 기본 파라미터 -----
    lookahead_ = declare_parameter<double>("lookahead", 1.5);     // [m]
    wheelbase_ = declare_parameter<double>("wheelbase", 0.34);    // [m]
    v_min_     = declare_parameter<double>("speed_min", 1.0);     // [m/s]
    v_max_     = declare_parameter<double>("speed_max", 4.0);     // [m/s]
    k_speed_   = declare_parameter<double>("k_speed",  2.5);      // curvature → speed
    k_accel_   = declare_parameter<double>("k_accel",  2.0);      // P gain for (v_ref - v)
    a_min_     = declare_parameter<double>("accel_min",-3.0);     // [m/s^2]
    a_max_     = declare_parameter<double>("accel_max", 3.0);     // [m/s^2]

    center_path_topic_ = declare_parameter<std::string>("center_path_topic", "center_path");
    left_path_topic_   = declare_parameter<std::string>("left_boundary",   "left_boundary");
    right_path_topic_  = declare_parameter<std::string>("right_boundary",  "right_boundary");
    odom_topic_        = declare_parameter<std::string>("odom_topic",      "odom0");
    drive_topic_       = declare_parameter<std::string>("drive_topic",     "ackermann_cmd0");

    // raceline CSV 경로
    center_path_csv_ = declare_parameter<std::string>(
        "center_path_csv",
        "/home/namgyu/race/src/racecar_simulator/maps/lane_process/icra2025/icra2025_raceline.csv"
    );

    // ----- Publisher / Subscriber -----
    drive_pub_ = create_publisher<ackermann_msgs::msg::AckermannDriveStamped>(
        drive_topic_, 10);

    // raceline Path (RViz)
    raceline_pub_ = create_publisher<nav_msgs::msg::Path>(
        "raceline_path", 10);

    // lookahead Marker (RViz)
    lookahead_pub_ = create_publisher<visualization_msgs::msg::Marker>(
        "lookahead_marker", 10);

    // simulator 에서 나오는 center/left/right path
    sub_center_ = create_subscription<nav_msgs::msg::Path>(
        center_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ center_path_from_topic_ = *msg; });

    sub_left_ = create_subscription<nav_msgs::msg::Path>(
        left_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ left_path_ = *msg; });

    sub_right_ = create_subscription<nav_msgs::msg::Path>(
        right_path_topic_, 1,
        [this](nav_msgs::msg::Path::SharedPtr msg){ right_path_ = *msg; });

    sub_odom_ = create_subscription<nav_msgs::msg::Odometry>(
        odom_topic_, rclcpp::QoS(rclcpp::KeepLast(1)).reliable(),
        [this](nav_msgs::msg::Odometry::SharedPtr msg){
          odom_ = *msg; has_odom_ = true;
        });

    // ----- CSV 에서 raceline 로드 (center_path_) -----
    loadCenterPathFromCsv(center_path_csv_);

    // 주행 타이머
    timer_ = create_wall_timer(std::chrono::milliseconds(10),
                               std::bind(&PurePursuitNode::onTimer, this));
  }

private:
  // CSV에서 raceline(center_path_) 읽기
  void loadCenterPathFromCsv(const std::string &csv_path) {
    center_path_.poses.clear();
    center_path_.header.frame_id = "map";

    std::ifstream ifs(csv_path);
    if (!ifs.is_open()) {
      RCLCPP_ERROR(this->get_logger(),
                   "Failed to open center_path csv: %s", csv_path.c_str());
      return;
    }

    std::string line;
    // 첫 줄(헤더) 스킵: x_m,y_m
    if (!std::getline(ifs, line)) {
      RCLCPP_ERROR(this->get_logger(),
                   "center_path csv is empty: %s", csv_path.c_str());
      return;
    }

    int count = 0;
    while (std::getline(ifs, line)) {
      if (line.empty()) continue;
      std::stringstream ss(line);
      std::string sx, sy;
      if (!std::getline(ss, sx, ',')) continue;
      if (!std::getline(ss, sy, ',')) continue;

      try {
        double x = std::stod(sx);
        double y = std::stod(sy);

        geometry_msgs::msg::PoseStamped ps;
        ps.header.frame_id = "map";
        ps.pose.position.x = x;
        ps.pose.position.y = y;
        ps.pose.position.z = 0.0;

        center_path_.poses.push_back(ps);
        ++count;
      } catch (const std::exception &e) {
        RCLCPP_WARN(this->get_logger(),
                    "Failed to parse line in center_path csv: '%s'", line.c_str());
      }
    }

    RCLCPP_INFO(this->get_logger(),
                "Loaded center_path (raceline) from csv: %s (points=%d)",
                csv_path.c_str(), count);
  }

  void onTimer() {
    if (!has_odom_ || center_path_.poses.empty()) return;

    // ----- raceline_path를 주기적으로 publish (RViz에서 항상 보이게) -----
    center_path_.header.frame_id = "map";
    center_path_.header.stamp = now();
    raceline_pub_->publish(center_path_);

    // ----- 현재 자세 -----
    const auto &p = odom_.pose.pose.position;
    const auto &q = odom_.pose.pose.orientation;
    double roll, pitch, yaw;
    tf2::Quaternion tq(q.x, q.y, q.z, q.w);
    tf2::Matrix3x3(tq).getRPY(roll, pitch, yaw);
    const double x = p.x, y = p.y;

    // ----- lookahead target -----
    int target_idx = findLookaheadIndex(center_path_, x, y, lookahead_);
    if (target_idx < 0) return;

    const auto &tp = center_path_.poses[target_idx].pose.position;

    // 차량 좌표계로 변환 (x 앞, y 왼쪽)
    const double dx = tp.x - x;
    const double dy = tp.y - y;
    const double xL =  std::cos(yaw) * dx + std::sin(yaw) * dy;
    const double yL = -std::sin(yaw) * dx + std::cos(yaw) * dy;
    if (xL <= 0.01) return;

    const double Ld = std::hypot(xL, yL);
    const double curvature = 2.0 * yL / (Ld * Ld);
    const double steer = std::atan(wheelbase_ * curvature);

    // ----- lookahead Marker publish (점으로) -----
    publishLookaheadMarker(target_idx);

    // ----- 속도 계획 -----
    double v_ref = std::max(v_min_, v_max_ - k_speed_ * std::abs(curvature));
    v_ref = std::min(v_ref, v_max_);
    const double v = odom_.twist.twist.linear.x;

    double a_cmd = k_accel_ * (v_ref - v);
    if (a_cmd > a_max_) a_cmd = a_max_;
    if (a_cmd < a_min_) a_cmd = a_min_;

    ackermann_msgs::msg::AckermannDriveStamped cmd;
    cmd.header.stamp = now();
    cmd.header.frame_id = "base_link";
    cmd.drive.steering_angle = steer;
    cmd.drive.acceleration   = a_cmd;

    drive_pub_->publish(cmd);
  }

  // lookahead 위치를 "점(SPHERE)" marker로 publish
  void publishLookaheadMarker(int idx) {
    if (idx < 0 || idx >= static_cast<int>(center_path_.poses.size())) return;

    const auto &tp = center_path_.poses[idx].pose.position;

    visualization_msgs::msg::Marker mk;
    mk.header.frame_id = "map";
    mk.header.stamp = now();
    mk.ns = "lookahead_point";
    mk.id = 0;
    mk.type = visualization_msgs::msg::Marker::SPHERE;   // 🔴 점(구) 마커
    mk.action = visualization_msgs::msg::Marker::ADD;

    mk.pose.position.x = tp.x;
    mk.pose.position.y = tp.y;
    mk.pose.position.z = 0.05;  // 라인에서 살짝 띄워서 보기 좋게
    mk.pose.orientation.x = 0.0;
    mk.pose.orientation.y = 0.0;
    mk.pose.orientation.z = 0.0;
    mk.pose.orientation.w = 1.0;

    // 점 크기
    mk.scale.x = 0.25;
    mk.scale.y = 0.25;
    mk.scale.z = 0.25;

    // 색 (연한 초록)
    mk.color.r = 0.1f;
    mk.color.g = 1.0f;
    mk.color.b = 0.1f;
    mk.color.a = 1.0f;

    mk.lifetime = rclcpp::Duration::from_seconds(0.2);

    lookahead_pub_->publish(mk);
  }

  // 거리 누적해서 lookahead index 찾기
  static int findLookaheadIndex(const nav_msgs::msg::Path &path,
                                double x, double y, double Ld) {
    if (path.poses.empty()) return -1;

    int closest = 0;
    double best = 1e18;
    for (size_t i = 0; i < path.poses.size(); ++i) {
      const auto &pt = path.poses[i].pose.position;
      double d2 = (pt.x - x)*(pt.x - x) + (pt.y - y)*(pt.y - y);
      if (d2 < best) { best = d2; closest = static_cast<int>(i); }
    }
    double accum = 0.0;
    for (size_t i = closest; i + 1 < path.poses.size(); ++i) {
      const auto &a = path.poses[i].pose.position;
      const auto &b = path.poses[i+1].pose.position;
      accum += std::hypot(b.x - a.x, b.y - a.y);
      if (accum >= Ld)
        return static_cast<int>(i + 1);
    }
    return static_cast<int>(path.poses.size() - 1);
  }

  // ----- 멤버 변수 -----
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr drive_pub_;
  rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr raceline_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr lookahead_pub_;

  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr sub_center_, sub_left_, sub_right_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr sub_odom_;
  rclcpp::TimerBase::SharedPtr timer_;

  nav_msgs::msg::Path center_path_;             // CSV에서 읽은 raceline (실제 추종용)
  nav_msgs::msg::Path center_path_from_topic_;  // simulator centerline (참고용)
  nav_msgs::msg::Path left_path_, right_path_;

  nav_msgs::msg::Odometry odom_;
  bool has_odom_{false};

  double lookahead_, wheelbase_;
  double v_min_, v_max_, k_speed_;
  double k_accel_, a_min_, a_max_;

  std::string center_path_topic_, left_path_topic_, right_path_topic_;
  std::string odom_topic_, drive_topic_;
  std::string center_path_csv_;
};

int main(int argc, char **argv){
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<PurePursuitNode>());
  rclcpp::shutdown();
  return 0;
}
