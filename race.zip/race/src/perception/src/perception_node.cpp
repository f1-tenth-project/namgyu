#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/float32.hpp>

class PerceptionNode : public rclcpp::Node {
public:
  PerceptionNode() : Node("perception_node")
  {
    // /scan 구독
    scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/scan0", 10,
      std::bind(&PerceptionNode::onScan, this, std::placeholders::_1));

    // 인지 결과 퍼블리셔들
    corner_active_pub_ = this->create_publisher<std_msgs::msg::Bool>("/corner_active", 10);
    corner_severity_pub_ = this->create_publisher<std_msgs::msg::Float32>("/corner_severity", 10);
    obs_front_pub_ = this->create_publisher<std_msgs::msg::Bool>("/obs_front", 10);
    obs_front_dist_pub_ = this->create_publisher<std_msgs::msg::Float32>("/obs_front_dist", 10);

    RCLCPP_INFO(this->get_logger(), "PerceptionNode started!");
  }

private:
  void onScan(const sensor_msgs::msg::LaserScan::SharedPtr msg)
  {
    (void)msg; // 지금은 안 씀 (경고 제거용)

    // TODO: 나중에 여기서 detectCornerHeavy, detectObstacleClusters 같은
    //       실제 인지 알고리즘 돌릴 예정

    std_msgs::msg::Bool corner_active;
    std_msgs::msg::Float32 corner_severity;
    std_msgs::msg::Bool obs_front;
    std_msgs::msg::Float32 obs_front_dist;

    // 현재는 더미 값 (전체 파이프라인 검증용)
    corner_active.data = false;
    corner_severity.data = 0.0f;
    obs_front.data = false;
    obs_front_dist.data = 999.0f;

    corner_active_pub_->publish(corner_active);
    corner_severity_pub_->publish(corner_severity);
    obs_front_pub_->publish(obs_front);
    obs_front_dist_pub_->publish(obs_front_dist);
  }

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr corner_active_pub_;
  rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr corner_severity_pub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr obs_front_pub_;
  rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr obs_front_dist_pub_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<PerceptionNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
