#!/usr/bin/env python3
import pandas as pd

src = "icra2025_centerline_c.csv"
dst = "icra2025_reftrack.csv"

df = pd.read_csv(src)

# 필요한 4개 컬럼만, 순서 맞춰서 선택
out = df[["x_m", "y_m", "w_tr_right_m", "w_tr_left_m"]].copy()

# 헤더를 np.loadtxt가 무시하게 # 붙여주고 싶다면:
out.to_csv(dst, index=False)
print(f"saved {dst} with columns:", list(out.columns))
