#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <ackermann_msgs/msg/ackermann_drive_stamped.hpp>

#include <chrono>
#include <cmath>
#include <algorithm>

class ControlNode : public rclcpp::Node {
public:
  ControlNode() : Node("control_node")
  {
    // ===== 파라미터 (pure_pursuit 원본과 동일하게) =====
    k_accel_ = this->declare_parameter<double>("k_accel", 2.0);    // P gain for (v_ref - v)
    a_min_   = this->declare_parameter<double>("accel_min", -3.0); // [m/s^2]
    a_max_   = this->declare_parameter<double>("accel_max",  3.0); // [m/s^2]

    // 토픽 이름
    odom_topic_   = "/odom0";
    drive_topic_  = "/ackermann_cmd0";

    // ===== 구독 =====
    // Decision에서 나온 레퍼런스 명령
    drive_ref_sub_ = this->create_subscription<ackermann_msgs::msg::AckermannDriveStamped>(
      "/drive_ref", 10,
      std::bind(&ControlNode::onDriveRef, this, std::placeholders::_1));

    // odom0 (현재 속도)
    odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_, 10,
      std::bind(&ControlNode::onOdom, this, std::placeholders::_1));

    // ===== 최종 명령 퍼블리셔 (시뮬레이터가 구독하는 토픽) =====
    drive_pub_ = this->create_publisher<ackermann_msgs::msg::AckermannDriveStamped>(
      drive_topic_, 10);

    // 타이머: 최신 ref + odom 기반으로 주기적으로 명령 생성
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(20),
      std::bind(&ControlNode::onTimer, this));

    RCLCPP_INFO(this->get_logger(), "ControlNode (PP accel) started!");
  }

private:
  void onDriveRef(const ackermann_msgs::msg::AckermannDriveStamped::SharedPtr msg)
  {
    drive_ref_ = *msg;
    has_drive_ref_ = true;
  }

  void onOdom(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    odom_ = *msg;
    has_odom_ = true;
  }

  void onTimer()
  {
    if (!has_drive_ref_ || !has_odom_) {
      return;
    }

    // ===== 목표 속도 / 조향 =====
    const double v_ref     = drive_ref_.drive.speed;
    const double steer_ref = drive_ref_.drive.steering_angle;

    // ===== 현재 속도 =====
    const double v = odom_.twist.twist.linear.x;

    // ===== 가속도 P 제어 (pure_pursuit 원본과 동일) =====
    double a_cmd = k_accel_ * (v_ref - v);
    if (a_cmd < a_min_) a_cmd = a_min_;
    if (a_cmd > a_max_) a_cmd = a_max_;

    // ===== 최종 명령 publish =====
    ackermann_msgs::msg::AckermannDriveStamped cmd;
    cmd.header.stamp = this->now();
    cmd.header.frame_id = "base_link";

    cmd.drive.steering_angle = steer_ref;
    cmd.drive.acceleration   = a_cmd;
    // cmd.drive.speed = v_ref;  // 필요하면 참조용으로만 채워도 됨

    drive_pub_->publish(cmd);
  }

  // 상태 변수
  ackermann_msgs::msg::AckermannDriveStamped drive_ref_;
  nav_msgs::msg::Odometry odom_;
  bool has_drive_ref_ = false;
  bool has_odom_      = false;

  // 파라미터
  double k_accel_, a_min_, a_max_;
  std::string odom_topic_, drive_topic_;

  // ROS 핸들
  rclcpp::Subscription<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr drive_ref_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<ackermann_msgs::msg::AckermannDriveStamped>::SharedPtr drive_pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ControlNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
